<?php
    date_default_timezone_set('Asia/Karachi');
    $dat = date('d-m-Y, l');
    $time_date = date('h:i:s, a');
?>